# NLA_CourseProject_VQA

Paper Link: https://arxiv.org/pdf/1505.00468.pdf

This repository is for VQA implementation and enhancement using Stacked Attention.

Currently the code is optimised to work on multiple gpu's for training and takes 7 hours for 30 epochs.
